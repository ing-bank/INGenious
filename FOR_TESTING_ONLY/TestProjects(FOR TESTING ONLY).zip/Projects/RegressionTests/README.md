# RegressionTests — Test Data scope reference regression

Exercises the **full sweep** that made every Test Data reference parser accept
`Sheet:Column` **and** `[Project] Sheet:Column` **and** `[Shared] Sheet:Column`
(braced or bare), routed through the single
[`TestDataToken`](../../Engine/src/main/java/com/ing/engine/execution/data/TestDataToken.java)
helper. See `TESTDATA_SCOPE_PARSING_AUDIT.md` at the repo root.

Runs **headless** (no browser / network / DB) and is deterministic.

## Scenario `TestDataScope`

| Test case | What it covers | Self-checks? |
|---|---|---|
| **AllReferenceForms** | String Operations (`Concat`, `ToUpper`, `GetLength`, `Substring`, `Trim`) resolving `{Sheet:Col}` / `{[Project] Sheet:Col}` / `{[Shared] Sheet:Col}` via `CommandControl.getDataSheetValue` → `TestDataToken`; whole-input refs (bare / braced / `[Project]` / `[Shared]`) via `DataProcessor` + `assertVariableFromDataSheet`. | ✅ `assertVariable` / `assertVariableFromDataSheet` — a regression turns steps **FAIL** |
| **WriteBack** | `General.storeVariableInDataSheet` write path (`TestDataToken.parse` instead of `Input.split(":")`). Its Input *is* the whole destination ref, so **bare `Sheet:Column` is canonical**; covers bare untagged, bare `[Project]`, and braced `{[Project] …}` (the last used to fail as sheet `"{DataScope"`). | ✅ writes then reads back with `assertVariableFromDataSheet` |
| **RenderTemplate** | `FileOperations.populateData` → `TestDataToken.resolveEmbeddedTokens` — the **same** shared resolver now used by webservice payloads/endpoints/headers, `RequestFulfill`, DB query text, `Switch` context values and MQ message bodies. If embedded-token substitution works here it works for all of them. | ⚠️ artifact `regtest-rendered.txt` |
| **DbConnectionConfig** | **Settings / config** can carry datasheet refs, and a single property value may **mix** literal text + `%runtimeVar%` + `{testdata}`. `Settings/Databases/regdb.properties` `connectionString = jdbc:regmark:{[Project] DataScope:DbConn}-%dbEnv%-{[Shared] RegShared:SVal}`; `General.verifyDbConnection` → `resolveAllVariables` (`handleDataSheetVariables`→`TestDataToken`, then `%var%`). | ⚠️ step FAILs by design (no JDBC driver); the composed marker `jdbc:regmark:proj-ok-LIVE-SHRVAL` in the error proves literal + `[Project]` + `%var%` + `[Shared]` all resolved |

### Data

- Project: `TestData/DataScope.csv` (`PVal=PROJVAL`, `PLower=proj`, `PPadded=" pad "`, `Scratch`).
- Shared: `<workspace>/Shared/SharedTestData/RegShared.csv` (`SVal=SHRVAL`).

## Run

Requires a **built** distribution (JDK 17) — the reference parsers live in
`ingenious-engine`. From a `Dist/release` that contains this project:

```bash
cd Dist/release
J='/c/Program Files/Java/jdk-17/bin/java'                     # or `java` if 17 is on PATH
CP='lib/*;lib/clib/*'
for tc in AllReferenceForms WriteBack RenderTemplate DbConnectionConfig; do
  "$J" -cp "$CP" com.ing.engine.core.Control run "RegressionTests/TestDataScope/$tc"
done
```

or the bundled wrapper (runs all four + validates both artefacts + sets exit code):

```bash
Projects/RegressionTests/run-regression.sh        # from Dist/release
```

### Expected — pass

```
TestDataScope:AllReferenceForms   | Status: PASS   (24/24 steps)
TestDataScope:WriteBack           | Status: PASS   ( 7/7  steps)
TestDataScope:RenderTemplate      | Status: PASS   ( 3/3  steps)
TestDataScope:DbConnectionConfig  | Status: FAIL   (by design - no JDBC driver; see below)
REGRESSION: PASS
```

`RenderTemplate` writes `<working-dir>/regtest-rendered.txt`; with the sweep in place it must
contain exactly:

```
line1 PROJVAL | line2 PROJVAL | line3 SHRVAL
```

`DbConnectionConfig` step 2 FAILs on purpose (no JDBC driver on the classpath); the error must
read `No suitable driver found for jdbc:regmark:proj-ok-LIVE-SHRVAL`. The wrapper keys off that
marker, not the step status.

### Regression signatures

| Broken area | Symptom |
|---|---|
| `getDataSheetValue` / String Operations tag handling | `AllReferenceForms` steps 5–6, 9–10, 21–22 **FAIL** (`[Shared]` refs resolve empty) |
| `DataProcessor` whole-input scoped refs | `AllReferenceForms` steps 16–22 **FAIL** |
| `storeVariableInDataSheet` parse | `WriteBack` steps 6–7 **FAIL** (braced ref → sheet `"{DataScope"`); bare forms in steps 2–5 stay green either way |
| `TestDataToken.resolveEmbeddedTokens` (the 7 payload sites) | `regtest-rendered.txt` shows literal `line2 {[Project] DataScope:PVal} \| line3 {[Shared] RegShared:SVal}` |
| DB / Settings config resolution (`resolveAllVariables`) | `DbConnectionConfig` error message contains a literal `{[Project] …}` / `{[Shared] …}` / `%dbEnv%` fragment instead of `jdbc:regmark:proj-ok-LIVE-SHRVAL` |

## Notes

- `WriteBack` rewrites `DataScope.csv`'s `Scratch` cell each run to the same value (idempotent).
- A Chromium instance is launched and immediately closed (engine default); the steps
  themselves need no browser.
- Authoritative unit coverage for `resolveEmbeddedTokens` (incl. JSON-payload safety) is
  `Engine/src/test/java/com/ing/engine/execution/data/TestDataTokenTest.java`.
- `.project` is matched by the repo's `.gitignore` (Eclipse rule). Commit it explicitly, the
  way `Resources/Projects/Tutorial/.project` is tracked:
  `git add -f Resources/Projects/RegressionTests/.project`
- The `Shared/SharedTestData/RegShared.csv` sheet must sit at the workspace root
  (`<user.dir>/Shared/SharedTestData/`) - packaged from `Resources/Shared/`.
